// The data in this file is loaded into bank4, address space "spaceb4"

#pragma bank 4
#pragma constseg RODATA_4

const int array_in_b4[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
