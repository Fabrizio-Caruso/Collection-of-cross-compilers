// The data in this file is loaded into bank1, address space "spaceb1"

#pragma bank 1
#pragma constseg RODATA_1

const int value_in_b1 = 89;

