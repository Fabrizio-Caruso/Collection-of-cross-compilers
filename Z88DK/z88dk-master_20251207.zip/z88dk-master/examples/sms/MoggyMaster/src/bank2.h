extern const unsigned char	pal_dalefran_psg[];
#define				pal_dalefran_psg_size 654
#define				pal_dalefran_psg_bank 2

extern const unsigned char	pal_gover_psg[];
#define				pal_gover_psg_size 974
#define				pal_gover_psg_bank 2

extern const unsigned char	pal_ingame_psg[];
#define				pal_ingame_psg_size 6659
#define				pal_ingame_psg_bank 2

extern const unsigned char	pal_psg1_psg[];
#define				pal_psg1_psg_size 31
#define				pal_psg1_psg_bank 2

extern const unsigned char	pal_psg2_psg[];
#define				pal_psg2_psg_size 69
#define				pal_psg2_psg_bank 2

extern const unsigned char	pal_psg3_psg[];
#define				pal_psg3_psg_size 58
#define				pal_psg3_psg_bank 2

extern const unsigned char	pal_psg4_psg[];
#define				pal_psg4_psg_size 41
#define				pal_psg4_psg_bank 2

extern const unsigned char	pal_select_psg[];
#define				pal_select_psg_size 34
#define				pal_select_psg_bank 2

extern const unsigned char	pal_start_psg[];
#define				pal_start_psg_size 46
#define				pal_start_psg_bank 2

extern const unsigned char	pal_title_psg[];
#define				pal_title_psg_size 2468
#define				pal_title_psg_bank 2

extern const unsigned char	pal_vs_psg[];
#define				pal_vs_psg_size 495
#define				pal_vs_psg_bank 2

