extern const unsigned char	ntsc_dalefran_psg[];
#define				ntsc_dalefran_psg_size 662
#define				ntsc_dalefran_psg_bank 3

extern const unsigned char	ntsc_gover_psg[];
#define				ntsc_gover_psg_size 1015
#define				ntsc_gover_psg_bank 3

extern const unsigned char	ntsc_ingame_psg[];
#define				ntsc_ingame_psg_size 7095
#define				ntsc_ingame_psg_bank 3

extern const unsigned char	ntsc_psg1_psg[];
#define				ntsc_psg1_psg_size 31
#define				ntsc_psg1_psg_bank 3

extern const unsigned char	ntsc_psg2_psg[];
#define				ntsc_psg2_psg_size 69
#define				ntsc_psg2_psg_bank 3

extern const unsigned char	ntsc_psg3_psg[];
#define				ntsc_psg3_psg_size 58
#define				ntsc_psg3_psg_bank 3

extern const unsigned char	ntsc_psg4_psg[];
#define				ntsc_psg4_psg_size 41
#define				ntsc_psg4_psg_bank 3

extern const unsigned char	ntsc_select_psg[];
#define				ntsc_select_psg_size 34
#define				ntsc_select_psg_bank 3

extern const unsigned char	ntsc_start_psg[];
#define				ntsc_start_psg_size 46
#define				ntsc_start_psg_bank 3

extern const unsigned char	ntsc_title_psg[];
#define				ntsc_title_psg_size 2513
#define				ntsc_title_psg_bank 3

extern const unsigned char	ntsc_vs_psg[];
#define				ntsc_vs_psg_size 498
#define				ntsc_vs_psg_bank 3

