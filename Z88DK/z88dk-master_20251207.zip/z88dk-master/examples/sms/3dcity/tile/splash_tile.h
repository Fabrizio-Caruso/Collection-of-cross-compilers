#ifndef _SPLASH_TILE_H_
#define _SPLASH_TILE_H_

void engine_tile_splash_load_tiles(int start, int count);
void engine_tile_splash_show_tiles(unsigned char x, unsigned char y, unsigned char width, unsigned char height);

#endif//_SPLASH_TILE_H_
