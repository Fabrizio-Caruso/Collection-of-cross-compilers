#ifndef _MUSIC_MANAGER_H_
#define _MUSIC_MANAGER_H_

void engine_music_manager_load_module();
void engine_music_manager_start_module();
void engine_music_manager_play_module();
void engine_music_manager_pause_module();

#endif//_MUSIC_MANAGER_H_
