//banks include 
#ifdef TARGET_GG 
#include "assets_gg/common.h"
#else 
#include "assets_sms/common.h"
#endif 
