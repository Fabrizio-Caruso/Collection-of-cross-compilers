#ifndef GAME_HUD_H
#define GAME_HUD_H

void hud_load( );
void hud_refresh( );

#endif /* GAME_HUD_H */
