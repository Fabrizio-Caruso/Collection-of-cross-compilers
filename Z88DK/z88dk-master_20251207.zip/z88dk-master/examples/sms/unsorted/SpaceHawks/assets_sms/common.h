extern const unsigned char	alien1_bin[];
#define				alien1_bin_size 192

extern const unsigned char	alien1_bomb_bin[];
#define				alien1_bomb_bin_size 32

extern const unsigned char	alien2_bin[];
#define				alien2_bin_size 192

extern const unsigned char	alien2_bomb_bin[];
#define				alien2_bomb_bin_size 32

extern const unsigned char	alien3_bin[];
#define				alien3_bin_size 192

extern const unsigned char	alien3_bomb_bin[];
#define				alien3_bomb_bin_size 32

extern const unsigned char	alien4_bin[];
#define				alien4_bin_size 192

extern const unsigned char	alien4_bomb_bin[];
#define				alien4_bomb_bin_size 32

extern const unsigned char	alien5_bin[];
#define				alien5_bin_size 192

extern const unsigned char	alien5_bomb_bin[];
#define				alien5_bomb_bin_size 32

extern const unsigned char	alien6_bin[];
#define				alien6_bin_size 192

extern const unsigned char	alien6_bomb_bin[];
#define				alien6_bomb_bin_size 32

extern const unsigned char	alien7_bin[];
#define				alien7_bin_size 192

extern const unsigned char	alien7_bomb_bin[];
#define				alien7_bomb_bin_size 32

extern const unsigned char	alien8_bin[];
#define				alien8_bin_size 192

extern const unsigned char	alien8_bomb_bin[];
#define				alien8_bomb_bin_size 32

extern const unsigned char	amstrad_font_bin[];
#define				amstrad_font_bin_size 6144

extern const unsigned char	bonus_300pts_bin[];
#define				bonus_300pts_bin_size 96

extern const unsigned char	bullet_bin[];
#define				bullet_bin_size 32

extern const unsigned char	font_lib_bin[];
#define				font_lib_bin_size 3072

extern const unsigned char	logo_sm_psgcompr[];
#define				logo_sm_psgcompr_size 3151

extern const unsigned char	mine_bin[];
#define				mine_bin_size 32

extern const unsigned char	selector_bin[];
#define				selector_bin_size 64

extern const unsigned char	sfx_back_sn7[];
#define				sfx_back_sn7_size 23

extern const unsigned char	sfx_back2_sn7[];
#define				sfx_back2_sn7_size 12

extern const unsigned char	sfx_dying_sn7[];
#define				sfx_dying_sn7_size 45

extern const unsigned char	sfx_fire_sn7[];
#define				sfx_fire_sn7_size 12

extern const unsigned char	sfx_launch_sn7[];
#define				sfx_launch_sn7_size 89

extern const unsigned char	sfx_new_life_sn7[];
#define				sfx_new_life_sn7_size 23

extern const unsigned char	sfx_score_update_sn7[];
#define				sfx_score_update_sn7_size 23

extern const unsigned char	sfx_sw_sn7[];
#define				sfx_sw_sn7_size 1068

extern const unsigned char	shawks_pal_bin[];
#define				shawks_pal_bin_size 10

extern const unsigned char	ship_bin[];
#define				ship_bin_size 1280

extern const unsigned char	spritesmind_pal_bin[];
#define				spritesmind_pal_bin_size 16

