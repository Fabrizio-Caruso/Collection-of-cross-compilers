#ifndef _BINARIES_H_
#define _BINARIES_H_

#define RAWBIN_SIZE  1513

extern unsigned char rawbin[];
extern unsigned char rawbin_end[];

extern unsigned char rawbin_zx7[];
extern unsigned char rawbin_zx7_end[];

extern unsigned char rawbin_ap[];
extern unsigned char rawbin_ap_end[];

#endif
