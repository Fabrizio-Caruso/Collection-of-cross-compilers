extern const unsigned char	monsterblob_psgcompr[];
#define				monsterblob_psgcompr_size 288
#define				monsterblob_psgcompr_bank 13

extern const unsigned char	skullb_psgcompr[];
#define				skullb_psgcompr_size 776
#define				skullb_psgcompr_bank 13

extern const unsigned char	stage8_psg[];
#define				stage8_psg_size 9572
#define				stage8_psg_bank 13

extern const unsigned char	stage8animtilesamov_bin[];
#define				stage8animtilesamov_bin_size 1792
#define				stage8animtilesamov_bin_bank 13

extern const unsigned char	stage8animtilesbmov_bin[];
#define				stage8animtilesbmov_bin_size 1792
#define				stage8animtilesbmov_bin_bank 13

extern const unsigned char	stage8animtilescloudsmov_bin[];
#define				stage8animtilescloudsmov_bin_size 256
#define				stage8animtilescloudsmov_bin_bank 13

extern const unsigned char	stage8bossb_psgcompr[];
#define				stage8bossb_psgcompr_size 1598
#define				stage8bossb_psgcompr_bank 13

extern const unsigned char	stage8bossc_psgcompr[];
#define				stage8bossc_psgcompr_size 288
#define				stage8bossc_psgcompr_bank 13

