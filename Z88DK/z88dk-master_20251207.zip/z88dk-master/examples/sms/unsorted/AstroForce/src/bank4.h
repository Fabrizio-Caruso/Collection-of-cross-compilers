extern const unsigned char	endingstagetilemap_bin[];
#define				endingstagetilemap_bin_size 704
#define				endingstagetilemap_bin_bank 4

extern const unsigned char	endingstagetiles_psgcompr[];
#define				endingstagetiles_psgcompr_size 28
#define				endingstagetiles_psgcompr_bank 4

extern const unsigned char	intro2_psg[];
#define				intro2_psg_size 2189
#define				intro2_psg_bank 4

extern const unsigned char	introovni_psgcompr[];
#define				introovni_psgcompr_size 313
#define				introovni_psgcompr_bank 4

extern const unsigned char	introsideplayer_psgcompr[];
#define				introsideplayer_psgcompr_size 120
#define				introsideplayer_psgcompr_bank 4

extern const unsigned char	rectship_psgcompr[];
#define				rectship_psgcompr_size 165
#define				rectship_psgcompr_bank 4

extern const unsigned char	select_psg[];
#define				select_psg_size 424
#define				select_psg_bank 4

extern const unsigned char	stage3_psg[];
#define				stage3_psg_size 5916
#define				stage3_psg_bank 4

extern const unsigned char	stage4endboss_psgcompr[];
#define				stage4endboss_psgcompr_size 369
#define				stage4endboss_psgcompr_bank 4

extern const unsigned char	stage4endbossb_psgcompr[];
#define				stage4endbossb_psgcompr_size 48
#define				stage4endbossb_psgcompr_bank 4

extern const unsigned char	stage4endbossc_psgcompr[];
#define				stage4endbossc_psgcompr_size 369
#define				stage4endbossc_psgcompr_bank 4

extern const unsigned char	stage4middleboss_psgcompr[];
#define				stage4middleboss_psgcompr_size 603
#define				stage4middleboss_psgcompr_bank 4

extern const unsigned char	stage4palette_bin[];
#define				stage4palette_bin_size 16
#define				stage4palette_bin_bank 4

extern const unsigned char	stage4tilemap_l[];
#define				stage4tilemap_l_size 189
#define				stage4tilemap_l_bank 4

extern const unsigned char	stage4tilemap_m[];
#define				stage4tilemap_m_size 2112
#define				stage4tilemap_m_bank 4

extern const unsigned char	stage4tiles_psgcompr[];
#define				stage4tiles_psgcompr_size 1894
#define				stage4tiles_psgcompr_bank 4

extern const unsigned char	vulcantank_psgcompr[];
#define				vulcantank_psgcompr_size 440
#define				vulcantank_psgcompr_bank 4

extern const unsigned char	warning_psgcompr[];
#define				warning_psgcompr_size 129
#define				warning_psgcompr_bank 4

extern const unsigned char	waveship_psgcompr[];
#define				waveship_psgcompr_size 289
#define				waveship_psgcompr_bank 4

