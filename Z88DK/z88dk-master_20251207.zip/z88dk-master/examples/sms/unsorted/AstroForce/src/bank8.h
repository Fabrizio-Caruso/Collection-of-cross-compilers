extern const unsigned char	gameover_psg[];
#define				gameover_psg_size 576
#define				gameover_psg_bank 8

extern const unsigned char	introstage1tilemap_bin[];
#define				introstage1tilemap_bin_size 640
#define				introstage1tilemap_bin_bank 8

extern const unsigned char	introstage1tiles_psgcompr[];
#define				introstage1tiles_psgcompr_size 2409
#define				introstage1tiles_psgcompr_bank 8

extern const unsigned char	introstage2tilemap_bin[];
#define				introstage2tilemap_bin_size 704
#define				introstage2tilemap_bin_bank 8

extern const unsigned char	introstage2tiles_psgcompr[];
#define				introstage2tiles_psgcompr_size 306
#define				introstage2tiles_psgcompr_bank 8

extern const unsigned char	playershoot_psgcompr[];
#define				playershoot_psgcompr_size 86
#define				playershoot_psgcompr_bank 8

extern const unsigned char	stage4_psg[];
#define				stage4_psg_size 10079
#define				stage4_psg_bank 8

extern const unsigned char	stage7a_psg[];
#define				stage7a_psg_size 1497
#define				stage7a_psg_bank 8

