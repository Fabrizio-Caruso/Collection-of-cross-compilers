extern const unsigned char	animtilestage1_bin[];
#define				animtilestage1_bin_size 128
#define				animtilestage1_bin_bank 10

extern const unsigned char	introstar_psgcompr[];
#define				introstar_psgcompr_size 14
#define				introstar_psgcompr_bank 10

extern const unsigned char	powerup_psgcompr[];
#define				powerup_psgcompr_size 165
#define				powerup_psgcompr_bank 10

extern const unsigned char	scrolltilestage1_bin[];
#define				scrolltilestage1_bin_size 192
#define				scrolltilestage1_bin_bank 10

extern const unsigned char	skull_psgcompr[];
#define				skull_psgcompr_size 744
#define				skull_psgcompr_bank 10

extern const unsigned char	spaceanimtiles_bin[];
#define				spaceanimtiles_bin_size 448
#define				spaceanimtiles_bin_bank 10

extern const unsigned char	spaceasteroidbig_psgcompr[];
#define				spaceasteroidbig_psgcompr_size 210
#define				spaceasteroidbig_psgcompr_bank 10

extern const unsigned char	spaceasteroidlittle_psgcompr[];
#define				spaceasteroidlittle_psgcompr_size 28
#define				spaceasteroidlittle_psgcompr_bank 10

extern const unsigned char	spaceasteroidmedium_psgcompr[];
#define				spaceasteroidmedium_psgcompr_size 104
#define				spaceasteroidmedium_psgcompr_bank 10

extern const unsigned char	stage1palette_bin[];
#define				stage1palette_bin_size 9
#define				stage1palette_bin_bank 10

extern const unsigned char	stage1tilemap_l[];
#define				stage1tilemap_l_size 512
#define				stage1tilemap_l_bank 10

extern const unsigned char	stage1tilemap_m[];
#define				stage1tilemap_m_size 4608
#define				stage1tilemap_m_bank 10

extern const unsigned char	stage1tiles_psgcompr[];
#define				stage1tiles_psgcompr_size 130
#define				stage1tiles_psgcompr_bank 10

extern const unsigned char	stage2_psg[];
#define				stage2_psg_size 8328
#define				stage2_psg_bank 10

extern const unsigned char	stage3endboss_psgcompr[];
#define				stage3endboss_psgcompr_size 476
#define				stage3endboss_psgcompr_bank 10

extern const unsigned char	stage8lateral_psgcompr[];
#define				stage8lateral_psgcompr_size 258
#define				stage8lateral_psgcompr_bank 10

