extern const unsigned char	fortresssearch_psgcompr[];
#define				fortresssearch_psgcompr_size 719
#define				fortresssearch_psgcompr_bank 3

extern const unsigned char	logopalette_bin[];
#define				logopalette_bin_size 16
#define				logopalette_bin_bank 3

extern const unsigned char	logotilemap_l[];
#define				logotilemap_l_size 28
#define				logotilemap_l_bank 3

extern const unsigned char	logotilemap_m[];
#define				logotilemap_m_size 896
#define				logotilemap_m_bank 3

extern const unsigned char	logotiles_psgcompr[];
#define				logotiles_psgcompr_size 2674
#define				logotiles_psgcompr_bank 3

extern const unsigned char	spacestation_psgcompr[];
#define				spacestation_psgcompr_size 187
#define				spacestation_psgcompr_bank 3

extern const unsigned char	stage2palette_bin[];
#define				stage2palette_bin_size 16
#define				stage2palette_bin_bank 3

extern const unsigned char	stage2tilemap_l[];
#define				stage2tilemap_l_size 512
#define				stage2tilemap_l_bank 3

extern const unsigned char	stage2tilemap_m[];
#define				stage2tilemap_m_size 8576
#define				stage2tilemap_m_bank 3

extern const unsigned char	stage2tiles_psgcompr[];
#define				stage2tiles_psgcompr_size 2645
#define				stage2tiles_psgcompr_bank 3

extern const unsigned char	ww2ship_psgcompr[];
#define				ww2ship_psgcompr_size 96
#define				ww2ship_psgcompr_bank 3

