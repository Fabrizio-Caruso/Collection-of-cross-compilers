extern const unsigned char	afterboss_psg[];
#define				afterboss_psg_size 571
#define				afterboss_psg_bank 9

extern const unsigned char	firetiles_bin[];
#define				firetiles_bin_size 1024
#define				firetiles_bin_bank 9

extern const unsigned char	fortressphantom_psgcompr[];
#define				fortressphantom_psgcompr_size 385
#define				fortressphantom_psgcompr_bank 9

extern const unsigned char	norefuge_psg[];
#define				norefuge_psg_size 357
#define				norefuge_psg_bank 9

extern const unsigned char	stage1endboss_psgcompr[];
#define				stage1endboss_psgcompr_size 744
#define				stage1endboss_psgcompr_bank 9

extern const unsigned char	stage1middleboss_psgcompr[];
#define				stage1middleboss_psgcompr_size 610
#define				stage1middleboss_psgcompr_bank 9

extern const unsigned char	stage2endboss_psgcompr[];
#define				stage2endboss_psgcompr_size 806
#define				stage2endboss_psgcompr_bank 9

extern const unsigned char	stage7middleboss_psgcompr[];
#define				stage7middleboss_psgcompr_size 1204
#define				stage7middleboss_psgcompr_bank 9

extern const unsigned char	stage7palette_bin[];
#define				stage7palette_bin_size 16
#define				stage7palette_bin_bank 9

extern const unsigned char	stage7tilemap_l[];
#define				stage7tilemap_l_size 480
#define				stage7tilemap_l_bank 9

extern const unsigned char	stage7tilemap_m[];
#define				stage7tilemap_m_size 8896
#define				stage7tilemap_m_bank 9

extern const unsigned char	stage7tiles_psgcompr[];
#define				stage7tiles_psgcompr_size 1161
#define				stage7tiles_psgcompr_bank 9

