extern const unsigned char	intro3_psg[];
#define				intro3_psg_size 4880
#define				intro3_psg_bank 5

extern const unsigned char	littleexplosion_psgcompr[];
#define				littleexplosion_psgcompr_size 23
#define				littleexplosion_psgcompr_bank 5

extern const unsigned char	monsterhead_psgcompr[];
#define				monsterhead_psgcompr_size 643
#define				monsterhead_psgcompr_bank 5

extern const unsigned char	monstermissil_psgcompr[];
#define				monstermissil_psgcompr_size 394
#define				monstermissil_psgcompr_bank 5

extern const unsigned char	stage1_psg[];
#define				stage1_psg_size 9081
#define				stage1_psg_bank 5

extern const unsigned char	stage7endboss_psgcompr[];
#define				stage7endboss_psgcompr_size 393
#define				stage7endboss_psgcompr_bank 5

extern const unsigned char	vulcanbird_psgcompr[];
#define				vulcanbird_psgcompr_size 480
#define				vulcanbird_psgcompr_bank 5

extern const unsigned char	vulcanlaser_psgcompr[];
#define				vulcanlaser_psgcompr_size 70
#define				vulcanlaser_psgcompr_bank 5

extern const unsigned char	vulcanlava_psgcompr[];
#define				vulcanlava_psgcompr_size 123
#define				vulcanlava_psgcompr_bank 5

extern const unsigned char	vulcanvulcan_psgcompr[];
#define				vulcanvulcan_psgcompr_size 37
#define				vulcanvulcan_psgcompr_bank 5

extern const unsigned char	ww2zeppelin_psgcompr[];
#define				ww2zeppelin_psgcompr_size 223
#define				ww2zeppelin_psgcompr_bank 5

