extern const unsigned char	boss2_psg[];
#define				boss2_psg_size 6448
#define				boss2_psg_bank 14

extern const unsigned char	player_psgcompr[];
#define				player_psgcompr_size 370
#define				player_psgcompr_bank 14

extern const unsigned char	stage8palette_bin[];
#define				stage8palette_bin_size 16
#define				stage8palette_bin_bank 14

extern const unsigned char	stage8tilemap_l[];
#define				stage8tilemap_l_size 500
#define				stage8tilemap_l_bank 14

extern const unsigned char	stage8tilemap_m[];
#define				stage8tilemap_m_size 6848
#define				stage8tilemap_m_bank 14

extern const unsigned char	stage8tiles_psgcompr[];
#define				stage8tiles_psgcompr_size 1579
#define				stage8tiles_psgcompr_bank 14

extern const unsigned char	vulcanstation_psgcompr[];
#define				vulcanstation_psgcompr_size 546
#define				vulcanstation_psgcompr_bank 14

