extern const unsigned char	boss_psg[];
#define				boss_psg_size 6844
#define				boss_psg_bank 12

extern const unsigned char	escape_psg[];
#define				escape_psg_size 2906
#define				escape_psg_bank 12

extern const unsigned char	flight_psg[];
#define				flight_psg_size 5000
#define				flight_psg_bank 12

extern const unsigned char	introstage3tilemap_bin[];
#define				introstage3tilemap_bin_size 768
#define				introstage3tilemap_bin_bank 12

extern const unsigned char	introstage3tiles_psgcompr[];
#define				introstage3tiles_psgcompr_size 691
#define				introstage3tiles_psgcompr_bank 12

