extern const unsigned char	spaceshooter_psgcompr[];
#define				spaceshooter_psgcompr_size 324
#define				spaceshooter_psgcompr_bank 11

extern const unsigned char	stage5_psg[];
#define				stage5_psg_size 7367
#define				stage5_psg_bank 11

extern const unsigned char	stage7_psg[];
#define				stage7_psg_size 7712
#define				stage7_psg_bank 11

