extern const unsigned char	intro1_psg[];
#define				intro1_psg_size 2369
#define				intro1_psg_bank 15

