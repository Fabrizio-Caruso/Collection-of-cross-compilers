extern const unsigned char	bone_psgcompr[];
#define				bone_psgcompr_size 282
#define				bone_psgcompr_bank 7

extern const unsigned char	cursors_psgcompr[];
#define				cursors_psgcompr_size 11
#define				cursors_psgcompr_bank 7

extern const unsigned char	enemyshoot_psgcompr[];
#define				enemyshoot_psgcompr_size 89
#define				enemyshoot_psgcompr_bank 7

extern const unsigned char	fortresswave_psgcompr[];
#define				fortresswave_psgcompr_size 108
#define				fortresswave_psgcompr_bank 7

extern const unsigned char	stage3palette_bin[];
#define				stage3palette_bin_size 16
#define				stage3palette_bin_bank 7

extern const unsigned char	stage3tilemap_l[];
#define				stage3tilemap_l_size 340
#define				stage3tilemap_l_bank 7

extern const unsigned char	stage3tilemap_m[];
#define				stage3tilemap_m_size 9856
#define				stage3tilemap_m_bank 7

extern const unsigned char	stage3tiles_psgcompr[];
#define				stage3tiles_psgcompr_size 623
#define				stage3tiles_psgcompr_bank 7

extern const unsigned char	stage5endboss_psgcompr[];
#define				stage5endboss_psgcompr_size 743
#define				stage5endboss_psgcompr_bank 7

extern const unsigned char	stage6_psg[];
#define				stage6_psg_size 2108
#define				stage6_psg_bank 7

extern const unsigned char	stage7animtiles_bin[];
#define				stage7animtiles_bin_size 256
#define				stage7animtiles_bin_bank 7

extern const unsigned char	stage7animtilesc_bin[];
#define				stage7animtilesc_bin_size 256
#define				stage7animtilesc_bin_bank 7

extern const unsigned char	stage7animtilesd_bin[];
#define				stage7animtilesd_bin_size 256
#define				stage7animtilesd_bin_bank 7

extern const unsigned char	stage7animtilese_bin[];
#define				stage7animtilese_bin_size 256
#define				stage7animtilese_bin_bank 7

extern const unsigned char	ww2plane_psgcompr[];
#define				ww2plane_psgcompr_size 798
#define				ww2plane_psgcompr_bank 7

extern const unsigned char	ww2tank_psgcompr[];
#define				ww2tank_psgcompr_size 338
#define				ww2tank_psgcompr_bank 7

