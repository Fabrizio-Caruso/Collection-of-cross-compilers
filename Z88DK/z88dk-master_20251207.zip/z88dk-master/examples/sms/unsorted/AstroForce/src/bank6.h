extern const unsigned char	bombship_psgcompr[];
#define				bombship_psgcompr_size 280
#define				bombship_psgcompr_bank 6

extern const unsigned char	fortresscannon_psgcompr[];
#define				fortresscannon_psgcompr_size 366
#define				fortresscannon_psgcompr_bank 6

extern const unsigned char	logo_psg[];
#define				logo_psg_size 6348
#define				logo_psg_bank 6

extern const unsigned char	spreadship_psgcompr[];
#define				spreadship_psgcompr_size 147
#define				spreadship_psgcompr_bank 6

extern const unsigned char	stage5palette_bin[];
#define				stage5palette_bin_size 16
#define				stage5palette_bin_bank 6

extern const unsigned char	stage5tilemap_l[];
#define				stage5tilemap_l_size 440
#define				stage5tilemap_l_bank 6

extern const unsigned char	stage5tilemap_m[];
#define				stage5tilemap_m_size 4544
#define				stage5tilemap_m_bank 6

extern const unsigned char	stage5tiles_psgcompr[];
#define				stage5tiles_psgcompr_size 671
#define				stage5tiles_psgcompr_bank 6

extern const unsigned char	stage6palette_bin[];
#define				stage6palette_bin_size 16
#define				stage6palette_bin_bank 6

extern const unsigned char	stage6tilemap_l[];
#define				stage6tilemap_l_size 48
#define				stage6tilemap_l_bank 6

extern const unsigned char	stage6tilemap_m[];
#define				stage6tilemap_m_size 768
#define				stage6tilemap_m_bank 6

extern const unsigned char	stage6tiles_psgcompr[];
#define				stage6tiles_psgcompr_size 1994
#define				stage6tiles_psgcompr_bank 6

extern const unsigned char	turnship_psgcompr[];
#define				turnship_psgcompr_size 350
#define				turnship_psgcompr_bank 6

extern const unsigned char	watertiles_bin[];
#define				watertiles_bin_size 256
#define				watertiles_bin_bank 6

extern const unsigned char	ww2cloud_psgcompr[];
#define				ww2cloud_psgcompr_size 61
#define				ww2cloud_psgcompr_bank 6

