extern const unsigned char	bigexplosion_psgcompr[];
#define				bigexplosion_psgcompr_size 167
#define				bigexplosion_psgcompr_bank 2

extern const unsigned char	ending_psg[];
#define				ending_psg_size 10058
#define				ending_psg_bank 2

extern const unsigned char	enemybomb_psg[];
#define				enemybomb_psg_size 24
#define				enemybomb_psg_bank 2

extern const unsigned char	enemylaser_psg[];
#define				enemylaser_psg_size 24
#define				enemylaser_psg_bank 2

extern const unsigned char	explosion_psg[];
#define				explosion_psg_size 25
#define				explosion_psg_bank 2

extern const unsigned char	font_psgcompr[];
#define				font_psgcompr_size 463
#define				font_psgcompr_bank 2

extern const unsigned char	fortressdoor_psgcompr[];
#define				fortressdoor_psgcompr_size 60
#define				fortressdoor_psgcompr_bank 2

extern const unsigned char	mikgamestilemap_bin[];
#define				mikgamestilemap_bin_size 128
#define				mikgamestilemap_bin_bank 2

extern const unsigned char	mikgamestiles_psgcompr[];
#define				mikgamestiles_psgcompr_size 254
#define				mikgamestiles_psgcompr_bank 2

extern const unsigned char	pause_psg[];
#define				pause_psg_size 35
#define				pause_psg_bank 2

extern const unsigned char	persons_bin[];
#define				persons_bin_size 504
#define				persons_bin_bank 2

extern const unsigned char	persons_psgcompr[];
#define				persons_psgcompr_size 2667
#define				persons_psgcompr_bank 2

extern const unsigned char	personspalette_bin[];
#define				personspalette_bin_size 16
#define				personspalette_bin_bank 2

extern const unsigned char	playershoot_psg[];
#define				playershoot_psg_size 8
#define				playershoot_psg_bank 2

extern const unsigned char	powerup_psg[];
#define				powerup_psg_size 46
#define				powerup_psg_bank 2

extern const unsigned char	ray_psg[];
#define				ray_psg_size 35
#define				ray_psg_bank 2

extern const unsigned char	selectorpalette_bin[];
#define				selectorpalette_bin_size 16
#define				selectorpalette_bin_bank 2

extern const unsigned char	selectortiles_psgcompr[];
#define				selectortiles_psgcompr_size 1730
#define				selectortiles_psgcompr_bank 2

extern const unsigned char	silence_psg[];
#define				silence_psg_size 49
#define				silence_psg_bank 2

