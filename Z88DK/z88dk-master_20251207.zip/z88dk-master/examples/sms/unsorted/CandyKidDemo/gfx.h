extern const unsigned char	font__palette__bin[];
#define				font__palette__bin_size 16

extern const unsigned char	font__tilemap__bin[];
#define				font__tilemap__bin_size 128

extern const unsigned char	font__tiles__psgcompr[];
#define				font__tiles__psgcompr_size 671

extern const unsigned char	splash__palette__bin[];
#define				splash__palette__bin_size 16

extern const unsigned char	splash__tilemap__stmcompr[];
#define				splash__tilemap__stmcompr_size 72

extern const unsigned char	splash__tiles__psgcompr[];
#define				splash__tiles__psgcompr_size 2089

extern const unsigned char	sprites__palette__bin[];
#define				sprites__palette__bin_size 9

extern const unsigned char	sprites__tiles__psgcompr[];
#define				sprites__tiles__psgcompr_size 950

extern const unsigned char	tree__palette__bin[];
#define				tree__palette__bin_size 11

extern const unsigned char	tree__tilemap__bin[];
#define				tree__tilemap__bin_size 8

extern const unsigned char	tree__tiles__psgcompr[];
#define				tree__tiles__psgcompr_size 82

