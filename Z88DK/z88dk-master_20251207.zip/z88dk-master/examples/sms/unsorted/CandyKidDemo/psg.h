extern const unsigned char	music_psg[];
#define				music_psg_size 1573

extern const unsigned char	sound1_psg[];
#define				sound1_psg_size 43

extern const unsigned char	sound2_psg[];
#define				sound2_psg_size 32

extern const unsigned char	sound3_psg[];
#define				sound3_psg_size 35

