extern const unsigned char	finish_psg[];
#define				finish_psg_size 88

extern const unsigned char	font_psgcompr[];
#define				font_psgcompr_size 398

extern const unsigned char	gamelogo_psgcompr[];
#define				gamelogo_psgcompr_size 1633

extern const unsigned char	gamelogotilemap_bin[];
#define				gamelogotilemap_bin_size 512

extern const unsigned char	gameover_psg[];
#define				gameover_psg_size 336

extern const unsigned char	mikgames_psgcompr[];
#define				mikgames_psgcompr_size 226

extern const unsigned char	mikgamestilemap_bin[];
#define				mikgamestilemap_bin_size 128

extern const unsigned char	ost_psg[];
#define				ost_psg_size 4464

extern const unsigned char	sfx_die_psg[];
#define				sfx_die_psg_size 43

extern const unsigned char	sfx_explosion_psg[];
#define				sfx_explosion_psg_size 25

extern const unsigned char	sfx_get_psg[];
#define				sfx_get_psg_size 32

extern const unsigned char	sfx_jump_psg[];
#define				sfx_jump_psg_size 10

extern const unsigned char	sfx_life_psg[];
#define				sfx_life_psg_size 35

extern const unsigned char	sprites_psgcompr[];
#define				sprites_psgcompr_size 836

extern const unsigned char	stage1tilemap_bin[];
#define				stage1tilemap_bin_size 1536

extern const unsigned char	stage2tilemap_bin[];
#define				stage2tilemap_bin_size 1536

extern const unsigned char	stage3tilemap_bin[];
#define				stage3tilemap_bin_size 1536

extern const unsigned char	stage4tilemap_bin[];
#define				stage4tilemap_bin_size 1536

extern const unsigned char	stage5tilemap_bin[];
#define				stage5tilemap_bin_size 1536

extern const unsigned char	stage6tilemap_bin[];
#define				stage6tilemap_bin_size 1536

extern const unsigned char	tiles_psgcompr[];
#define				tiles_psgcompr_size 561

